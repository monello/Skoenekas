<?php
/**
 * @author JLV Extension Team
 * @copyright jlvextension.com
 * @link http://jlvextension.com
 * @package JLV Facebook Login
 * @version 1.1.0
 * @license GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die;
// Include the syndicate functions only once
require_once dirname(__FILE__).'/helper.php';
require_once dirname(__FILE__).'/src/facebook.php';

$params->def('greeting', 1);
$appId = $params->get('appId', '');
$secret = $params->get('secret', '');

$loading = $params->get('loading', 1);
$loading_msg = $params->get('loading_msg', JText::_('MOD_JLV_FACEBOOKLOGIN_LOADING_MSG'));
$modalwidth = $params->get('modalwidth', 400);
$modalheight = $params->get('modalheight', 60);
$facebookimage = $params->get('facebookimage', '');
$loginform = $params->get('loginform', 1);
$forgot = $params->get('forgot', 1);
$forgotuser = $params->get('forgotuser', 1);
$create = $params->get('create', 1);
$user = JFactory::getUser();
$type	= modJLVFacebookLoginHelper::getType();
$return	= modJLVFacebookLoginHelper::getReturnURL($params, $type);
$user	= JFactory::getUser();
$facebook = new Facebook(array(
  'appId'  => $appId,
  'secret' => $secret,
));
$fbuser = $facebook->getUser();
if ($fbuser && $user->guest && isset($_GET['fb']) && $_GET['fb']=='login' ) {
	try {
		$user_profile = $facebook->api('/me');
		$isjoomlauser = modJLVFacebookLoginHelper::getJoomlaId($user_profile['email']);
		if((int)$isjoomlauser==0) {
			jimport( 'joomla.user.helper' );
			$password = JUserHelper::genRandomPassword(5);
			$joomlauser = modJLVFacebookLoginHelper::addJoomlaUser($user_profile['name'], $user_profile['username'], $password, $user_profile['email']);
		}
		else {
			$joomlauser = JFactory::getUser($isjoomlauser);
		}
		modJLVFacebookLoginHelper::loginFb($joomlauser,$return);
	}
	catch (FacebookApiException $e) {
		error_log($e);
		$fbuser = null;
	}
}
require JModuleHelper::getLayoutPath('mod_jlv_facebooklogin', $params->get('layout', 'default'));
