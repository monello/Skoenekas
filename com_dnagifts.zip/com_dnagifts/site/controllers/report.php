<?php
// no direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');
JLoader::register('DnaGiftsHelper', JPATH_COMPONENT.'/helpers/dnagifts.php');

class DnaGiftsControllerReport extends JControllerForm
{	

}
