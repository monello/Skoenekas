var surveydata = [
  {
    id: 1,
    catid: 1,
    question: 'I present truth and facts in a logical arranged and systematic way',
    answer: undefined,
    duration: 20
  },
  {
    id: 2,
    catid: 2,
    question: 'I make provision for future generations (e.g. children, grandchildren, etc.)',
    answer: undefined,
    duration: 8
  },
  {
    id: 3,
    catid: 3,
    question: 'I am highly motivated to organize and implement plans',
    answer: undefined,
    duration: 7
  },
  {
    id: 4,
    catid: 4,
    question: 'I am capable of having significant disagreements without offence',
    answer: undefined,
    duration: 7
  },
  {
    id: 5,
    catid: 5,
    question: 'I have a tremendous capacity to show love',
    answer: undefined,
    duration: 7
  },
  {
    id: 6,
    catid: 6,
    question: 'I quickly and accurately discern right and wrong, true and false',
    answer: undefined,
    duration: 7
  },
  {
    id: 7,
    catid: 7,
    question: 'I am very quick to recognize practical needs and respond quickly to meet them',
    answer: undefined,
    duration: 8
  },
  {
    id: 8,
    catid: 1,
    question: 'I  have a tendency to validate truth by weighing it against the facts',
    answer: undefined,
    duration: 8
  },
  {
    id: 9,
    catid: 2,
    question: 'I am able to accommodate people with diverse viewpoints from all walks of life',
    answer: undefined,
    duration: 8
  },
  {
    id: 10,
    catid: 3,
    question: 'I Prefer to be under authority in order to have authority',
    answer: undefined,
    duration: 7
  },
  {
    id: 11,
    catid: 4,
    question: 'I avoid being alone, I don�t like spending long periods alone, I thrive being around people',
    answer: undefined,
    duration: 8
  },
  {
    id: 12,
    catid: 5,
    question: 'I can intuitively sense the emotional atmosphere of a group or an individual, |I pick up the emotional frequency and status of people.',
    answer: undefined,
    duration: 9
  },
  {
    id: 13,
    catid: 6,
    question: 'I see everything as either black or white, there is no grey areas',
    answer: undefined,
    duration: 7
  },
  {
    id: 14,
    catid: 7,
    question: 'I derive great joy from showing hospitality',
    answer: undefined,
    duration: 7
  }
];