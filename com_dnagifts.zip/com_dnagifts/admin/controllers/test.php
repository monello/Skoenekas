<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controllerform library
jimport('joomla.application.component.controllerform');
 
/**
 * Tests Controller
 */
class DnaGiftsControllerTest extends JControllerForm
{
  /* The URL view list variable.
	*
	* @var string
	*/
	protected $view_list = 'tests';
  
}