<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controllerform library
jimport('joomla.application.component.controllerform');
 
/**
 * Question Controller
 */
class DnaGiftsControllerGift extends JControllerForm
{
  /* The URL view list variable.
	*
	* @var string
	*/
	protected $view_list = 'gifts';
  
}