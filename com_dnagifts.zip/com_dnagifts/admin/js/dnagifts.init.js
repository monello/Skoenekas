jQuery(document).ready(function() {
    Base.Helpers.init();
});
