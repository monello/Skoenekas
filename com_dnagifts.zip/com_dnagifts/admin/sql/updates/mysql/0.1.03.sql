UPDATE `#__dnagifts_lst_gift` SET `name` = 'Perceiver' WHERE `name` = 'Prophet';
UPDATE `#__dnagifts_lst_gift` SET `name` = 'Waarnemer' WHERE `name` = 'Profeet';

