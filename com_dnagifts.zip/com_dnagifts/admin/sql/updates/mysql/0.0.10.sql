ALTER TABLE `#__dnagifts_lnk_user_tests` DROP `progress`;
