ALTER TABLE `ccblm_dnagifts_lnk_user_tests` DROP `progress`;
