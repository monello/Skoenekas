UPDATE `#__dnagifts_lst_gift` SET `characters_image` = 'perceiver.png', `text_image` = 'perceiver.png', `text_token` = 'COM_DNAGIFTS_REPORT_PERCEIVER' WHERE `code` = 'P';
UPDATE `#__dnagifts_lst_gift` SET `characters_image` = 'servant.png', `text_image` = 'servant.png', `text_token` = 'COM_DNAGIFTS_REPORT_SERVANT' WHERE `code` = 'S';
UPDATE `#__dnagifts_lst_gift` SET `characters_image` = 'teacher.png', `text_image` = 'teacher.png', `text_token` = 'COM_DNAGIFTS_REPORT_TEACHER' WHERE `code` = 'T';
UPDATE `#__dnagifts_lst_gift` SET `characters_image` = 'exhorter.png', `text_image` = 'exhorter.png', `text_token` = 'COM_DNAGIFTS_REPORT_EXHORTER' WHERE `code` = 'E';
UPDATE `#__dnagifts_lst_gift` SET `characters_image` = 'giver.png', `text_image` = 'giver.png', `text_token` = 'COM_DNAGIFTS_REPORT_GIVER' WHERE `code` = 'G';
UPDATE `#__dnagifts_lst_gift` SET `characters_image` = 'ruler.png', `text_image` = 'ruler.png', `text_token` = 'COM_DNAGIFTS_REPORT_RULER' WHERE `code` = 'R';
UPDATE `#__dnagifts_lst_gift` SET `characters_image` = 'mercy.png', `text_image` = 'mercy.png', `text_token` = 'COM_DNAGIFTS_REPORT_MERCY' WHERE `code` = 'M';
