DROP VIEW IF EXISTS ccblm_dnagifts_churchlist;
CREATE VIEW ccblm_dnagifts_churchlist AS
SELECT distinct church_name FROM ccblm_dnagifts_pretest_info;

DROP VIEW IF EXISTS ccblm_dnagifts_pastorlist;
CREATE VIEW ccblm_dnagifts_pastorlist AS
SELECT distinct pastor_reverend  FROM ccblm_dnagifts_pretest_info;

DROP VIEW IF EXISTS ccblm_dnagifts_citylist;
CREATE VIEW ccblm_dnagifts_citylist AS
SELECT distinct your_city FROM ccblm_dnagifts_pretest_info;