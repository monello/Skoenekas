ALTER TABLE `#__dnagifts_test` ADD `use_timing` TINYINT( 1 ) NOT NULL DEFAULT '1' COMMENT 'Indicates if timing should be used in this test' AFTER `test_reason`;
