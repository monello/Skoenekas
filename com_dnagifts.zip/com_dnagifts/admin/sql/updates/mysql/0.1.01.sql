UPDATE `#__dnagifts_lst_gift` SET `color_hex_medium` = '#FF6262', `color_hex_light` = '#FF7F7F' WHERE `code` = 'P';
UPDATE `#__dnagifts_lst_gift` SET `color_hex_medium` = '#FFCC99', `color_hex_light` = '#FFEAB8' WHERE `code` = 'S';
UPDATE `#__dnagifts_lst_gift` SET `color_hex_medium` = '#FFFF99', `color_hex_light` = '#FFFCCD' WHERE `code` = 'T';
UPDATE `#__dnagifts_lst_gift` SET `color_hex_medium` = '#99CC99', `color_hex_light` = '#BFFFBF' WHERE `code` = 'E';
UPDATE `#__dnagifts_lst_gift` SET `color_hex_medium` = '#66CCCC', `color_hex_light` = '#AEF5FF' WHERE `code` = 'G';
UPDATE `#__dnagifts_lst_gift` SET `color_hex_medium` = '#6666CC', `color_hex_light` = '#ADAAFF' WHERE `code` = 'R';
UPDATE `#__dnagifts_lst_gift` SET `color_hex_medium` = '#9966CC', `color_hex_light` = '#D9B4FF' WHERE `code` = 'M';
